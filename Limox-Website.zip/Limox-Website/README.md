# Limox - Marketing Digital
Limox é uma plataforma de marketing digital desenvolvida para facilitar a venda e gestão de produtos digitais.

## Estrutura de Arquivos
- `index.html` - Página inicial do site.
- `contato.html` - Página de contato com email e WhatsApp.
- `assets/css/styles.css` - Estilos gerais do site.
- `assets/js/main.js` - Arquivo JavaScript para funcionalidades futuras.

## Contato
- **Email**: jmilionarios077@gmail.com
- **WhatsApp**: +55 11 94883-2531
