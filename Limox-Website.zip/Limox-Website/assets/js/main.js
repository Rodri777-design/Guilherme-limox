// main.js

// Código JavaScript para interações futuras
document.addEventListener("DOMContentLoaded", function() {
    console.log("Limox website loaded successfully!");
});